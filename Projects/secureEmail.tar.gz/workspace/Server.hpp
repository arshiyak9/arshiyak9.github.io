#ifndef SERVER_HPP_
#define SERVER_HPP_
#include <vector>
#include <string>
#include <iostream>
#include <stdlib.h>
#include "User.hpp"
#include "Message.hpp"
#include "DBUTILITY.hpp"
using namespace std;

typedef std::vector<User*> Userlist;//List of Users in server (make sure none can make the same username)
typedef std::vector<Message*> msgdet;

class Server{
	
public:
	string name; //name of server
	User* currentUser;
	int numOfUsers;
	bool loggedin;//true if user is logged in, false if not
	DBUTILITY *mydb;
	Userlist ul;
	
	//msgdet myMessages;
	
	Server();//constructor
	~Server(); //destructor
	
	void welcomeMessage(); //standard welcome message for server
	User* userExists(string name, string pwd);
	User* login(string u, string p); //log in to existing user
	User* reg(string u, string p); //register new user
	User* bootUp(); //get user to log in/register
	void routine(); //list of commands users can access when logged in
	
	//finds if a certain user exists in the list
	string encrypt(string uop);
	string DJBHash(string str);
};

#endif /* SERVER_HPP_ */
