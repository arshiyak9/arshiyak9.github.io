#include <iostream>
#include <stdlib.h>


using namespace std;

const string ENV[ 24 ] = {                 
   "COMSPEC", "DOCUMENT_ROOT", "GATEWAY_INTERFACE",   
   "HTTP_ACCEPT", "HTTP_ACCEPT_ENCODING",             
   "HTTP_ACCEPT_LANGUAGE", "HTTP_CONNECTION",         
   "HTTP_HOST", "HTTP_USER_AGENT", "PATH",            
   "QUERY_STRING", "REMOTE_ADDR", "REMOTE_PORT",      
   "REQUEST_METHOD", "REQUEST_URI", "SCRIPT_FILENAME",
   "SCRIPT_NAME", "SERVER_ADDR", "SERVER_ADMIN",      
   "SERVER_NAME","SERVER_PORT","SERVER_PROTOCOL",     
   "SERVER_SIGNATURE","SERVER_SOFTWARE" 
};

int main(){
   
   cout << "Content-type:text/html\r\n\r\n";
   
   cout << endl;
   cout << "<!doctype html><html><body></br>" <<endl;
   cout << "<div align = \"center\"><form name = \"GEEmail\" action = \"index.cgi\" method = \"GET\">" << endl;
   cout << "<h2>Welcome!!! Please provide your username and Password.</h2>" << endl;
   
   cout << "<br><label for=\"usernameis\">Username: </label>";
   cout << "<input type=\"text\" id=\"username \"><br />" << endl;
   
   cout << "<label for=\"passwordis\">password: </label>";
   cout << "<input type=\"password\" id=\"password\"><br>" << endl;
   
   cout << "<input type=\"submit\" value=\"send\"> <input type=\"reset\">";
   
   cout << "</form></div><div>" << endl;
   cout << "<table border = \"0\" cellspacing = \"2\">";
  
   cout << "<tr><td>" << endl;
   cout << "</td></tr>" << endl;
	
   cout << "</table></div>";
   cout << "</form></body></html>" << endl;
   
   return 0;
}
