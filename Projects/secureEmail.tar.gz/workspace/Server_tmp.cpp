#include<iostream>
#include<stdlib.h>
#include <string>
#include <cctype>
#include "Message.hpp"
#include "User.hpp"
#include "Server.hpp"
#include <ctype.h>
#include <limits>
#include "Frontend.hpp"
#include <sqlite3.h> 
#include "DBUTILITY.hpp"
using namespace std;



Server::Server(){ //create server object
	name = "GeeMail";
	loggedin = false;
//	userlist = mydb -> showServerUsers;
	currentUser = NULL;
	numOfUsers = 0;
	
}

void Server::welcomeMessage(){ //recite welcome message based on the current user
	cout << "Welcome to " << this->name << ", " << encrypt(this->currentUser->getUsername()) << "! "<<endl;
}

User* Server::login(string u, string p){ //log existing user into server
	if(this->userExists(u) != -1 && getUser(this->userExists(u))->verifyPass(p)){
		return getUser(this->userExists(u));
	}
	else{
		cout << "User Does Not Exist or Password is Incorrect; Try Again." << endl;
		string user;
		string pass;
		cout << "Enter Valid Username:" << endl;
		cin >> user;
		cout << "Enter Valid Password:" << endl;
		cin >> pass;
		return login(user, pass);
	}
}

User* Server::reg(string u, string p){ //register new user
	//string res = mydb->insertuser((char *) u);
	//cout << res << endl;
	/*
	User* temp = this->userlist;
	if(this->numOfUsers == 0){
		this->userlist = new User(u, p);
		this->numOfUsers++;
		return this->userlist;
	}
	else{
		for(int i = 0; i<(this->numOfUsers-1); i++){
			temp = temp->next;
		}
		if(temp->next == NULL){
			temp->next = new User(u, p);
			this->numOfUsers++;
		}
		return temp->next;
	}
	*/
	User user = *(new User(u, p));
	userlist.push_back(user);
	
	return &user;
}

//Used to be User*
User* Server::bootUp(){ //get user to log in or register
	cout << "Log in (l) or register (r)?" << endl;
	string log;
	cin >> log;
	User* sender = NULL;
	if(log.compare("l") == false && this->numOfUsers != 0){ //if user chooses to log in and there are existing members
		string user;
		string pass;
		cout << "Enter Username:" << endl;
		cin >> user;
		cout << "Enter Password:" << endl;
		cin >> pass;
		sender=login(user, pass);
		loggedin=true;
		return sender;
	}
	else if(log.compare("r") == false){ //if user chooses to register
		string us;
		string pa;
		cout << "Create Username:" << endl;
		cin >> us;
		cout << "Create Password:" << endl;
		cin >> pa;
		sender=reg(us, pa);
		loggedin = true;
		return sender;
	}
	else{ //if user typed in any other input
		cout << "Login Failed" << endl;
		loggedin = false;
		return bootUp();
	}
}

void Server::routine(){ //preform standard routine once user is logged in
	cout << endl << "You have: " << currentUser->getNumOfMessages() << " messages."; 
	currentUser->printAllMessages(); //brief synopsis of all of current user's messages
	cout<< endl << "What would you like to do?" << endl;
	string stuff;
	cout << "You can:"<<endl;
	cout << "Delete a message = d" << endl;
	cout << "Read a message = r" << endl;
	cout << "Send a message = s" << endl;
	cout << "Log out = l" << endl;
	cin >> stuff;
	if(stuff.compare("d") == false && currentUser->getNumOfMessages() > 0){ //if string typed in is d (delete a letter)
		cout << "Type the number of the message you'd like to delete:" << endl;
		int num = 10000000;
		cin >> num; //take user input for the number of the message they'd like to delete
		while(cin.fail() == true || (num>0 && num<=currentUser->getNumOfMessages()) == false ){ //only go forward if what they type is valid
			cin.clear(); //reset cin
			cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
			cout << "Valid Number Please:" << endl;
			cin >> num;
		}
		currentUser->deleteMessage(num); //delete the message the user wants to delete
	}
	else if(stuff.compare("r") == false && currentUser->getNumOfMessages() > 0){ //if string typed is r (read a message)
		cout << "Please choose the corresponding number on the message:" << endl;
		int i = 100000;
		cin >> i; //user chooses message to read
		while(cin.fail() == true || (i>currentUser->getNumOfMessages() && i<=0) ){ //while the user doesnt type a valid number
			cin.clear(); //clear user input
			cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
			cout << "Valid Number Please:" << endl;
			cin >> i;
		}
		cout << "Please enter the passphrase:" << endl;
		cin >> stuff; //user input for passphrase
		while(stuff.compare(encrypt(currentUser->getMessage(i-1)->getPassphrase())) == true){ //while the passphrase doesnt match
			cout << "Enter proper passcode:" <<endl;
			cin >> stuff;
		}
		currentUser->printWholeMessage(i-1); //print the message the user wants to read
	}
	else if(stuff.compare("s")== false){ //if string typed in is s
		cout << "To: ";
		string to;
		cin >> to; //get sender to choose recipient
		while (this->userExists(to) == -1){ //while the username with that user doesnt exist
			cout << endl << "Enter valid user: ";
			cin >> to;
		}
		int num = this->userExists(to); //retrieve the associated number with the user
		User* sendto = getUser(num); //retrieve the user
		cout << endl << "Header: "; 
		string header;
		cin >> header; //get sender to type header for message
		cout << endl<< "Message: ";
		string message;
		cin >> message; //get sender to type content for message
		cout << endl << "Passphrase: ";
		string p;
		cin >> p; //get sender to type shared passphrase for message
		currentUser->sendMessage(sendto, header, message, p); //send the message to the intended recipient]
		/*string msginsertstat = mydb-> insertmessage((char *)sendto, (char *) header, (char *) p, (char*) content, (char*) this->currentUser->getUsername());
		cout <<msginsertstat<<endl; */
		cout <<endl<< "Your message has been sent!" <<endl;
	}
	else if(stuff.compare("l")== false){ //if string typed in is l
		cout << "Until next time, " << encrypt(currentUser->getUsername()) << endl; //goodbye message
		loggedin = false; //logged in status of server is changed to false
	}
	else{
		cout << "Input not valid, try again" << endl;
		routine(); //this function calls itself again
	}
}

int Server::userExists(string name){
	/*
	User* retrieved = NULL;
	for(int i =0 ; i<this->numOfUsers; i++){
		retrieved = getUser(i);
		if(retrieved->getUsername().compare(encrypt(name)) == false){
			return i;
		}
	}
	return -1;
	*/
    for(int i = 0; i < userlist.size(); i++) {
    	User temp = userlist.at(i);
    	
    	if(temp.getUsername().compare(encrypt(name)) == false) {
    		return i;
    	}
    }
	return -1;
	/*
	if(mydb ->getMyUser((char*)name.compare(encrypt(name)) == false))
	{
		return 1;
	}
	else {
		return -1;	
	} 
	*/
}

User* Server::getUser(int num){ //retrieve a specific user from server's user list
	//User *retrieved = this->userlist;
	/*
	for(int i=0; i<num; i++){
		retrieved = retrieved->next;
	}
	return retrieved;
	*/
	return &(userlist.at(num));
}

// Based on algorithm developed by Professor Daniel J. Bernstein
// Source for code: http://www.partow.net/programming/hashfunctions/
string Server::DJBHash(string str)
{
   unsigned int hash = 5381;

   for (int i = 0; i < str.length(); ++i)
   {
      hash = ((hash << 5) + hash) + (str.at(i));
   }

   return to_string(hash);
}

// Using "stretching" algorithm as discussed in class 22
string Server::encrypt(string uop){
	string salt = "puggopants";
	string encrypted = "0";
	
	// "Stretch" hash 3 times
	for(int i = 0; i < 3; i++){
		encrypted = DJBHash(encrypted + uop + salt);
	}
	
	return encrypted;
}
