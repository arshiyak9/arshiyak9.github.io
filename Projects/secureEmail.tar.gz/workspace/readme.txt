Note: in order to get hash to run correctly you need to compile with -std=c++0x
        type: g++ Main.cpp -std=c++0x
        
        
SQLQUERY --> sqlite3 new.db
##create table USERS( ID integer primary key autoincrement, NAME text, ENCPWD BINARY(64) NOT NULL, DESC text);  
##CREATE TABLE MESSAGES (ID INTEGER PRIMARY KEY, USERNAME TEXT, HEADER TEXT, PASSPHRASE TEXT, CONTENT TEXT, SENTFROM TEXT, TIME TIMESTAMP, FOREIGN KEY (USERNAME) REFERENCES USERS(NAME));

##insert into MESSAGES ( USERNAME, HEADER, PASSPHRASE, CONTENT, SENTFROM, TIME) values("cold", "MYHEADERINFO", "MYPASSINFO", "MYCONTENT", "ALISHA", datetime());                                                                                          
## SELECT * FROM MESSAGES;  
## PRAGMA TABLE_INFO (MESSAGES);
## PRAGMA TABLE_INFO (USERS);