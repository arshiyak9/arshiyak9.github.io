#include "Message.hpp"
#include "User.hpp"
#include <stdlib.h>
#include <string>
#include <iostream>
#include "DBUTILITY.hpp"
using namespace std;

User::User(string u, string p){ //constructor for User
	username = u; //set the username
	password = encrypt(p); //set the password
	numOfMessages = 0; //number of messages new user has is 0 in beginning
	messageList = NULL; //message list for the new user has nothing, so initialize to NULL
	next = NULL; //see above, initialized to NULL
} //end constructor

void User::sendMessage(User* sendTo, string header, string message, string p){ //send a message
	Message *messageToSend = new Message(this->username, header, message, p); //construct new message using the current users name and the messages they want to send
	if(sendTo->numOfMessages == 0){ //if the user has no messages
		sendTo->messageList = messageToSend; //set their message list directly to this message 
	} //end if
	else{ //if the user has messages
		getMessage((sendTo->numOfMessages)-1)->next = messageToSend; //set the next message in the list to be the new message
	} //end else
	sendTo->numOfMessages++; //add 1 to the number of messages the user has
} //end send message

Message* User::getMessage(int num){ //pull a certain message
	Message *retrieved = this->messageList; //set pointer equal to the users message list
	for(int i=0; i<num; i++){ //iterate through list until the proper message is pulled
		retrieved = retrieved->next; 
	} //end for
	return retrieved; //return proper message
}

void User::printAllMessages(){ //print a brief synopsis of every message in the user's message list
	Message* toPrint = NULL;
	for(int i=0; i<this->numOfMessages; i++){
		toPrint = this->getMessage(i);
		cout <<endl<< "#" << (i+1) << endl;
		cout << "From: " << toPrint->getUsername() <<endl;
		cout << "Subject: " << toPrint->getHeader() << endl;
		cout << endl;
	}
}

void User::printWholeMessage(int i){ // print an entire message in the user's message list
	Message* toPrint = this->getMessage(i);
	cout << endl << "From: " << toPrint->getUsername() <<endl;
	cout << "Subject: " << toPrint->getHeader() << endl;
	cout << "Message: " << toPrint->getContent() <<endl;
}

void User::deleteMessage(int num){ //use to delete message from user's message list
	Message *previous = this->messageList;
	Message *deletethis = NULL;
	for(int i; i<(num-1); i++){
		previous = previous->next;
	}
	deletethis = previous->next;
	previous->next = NULL;
	delete deletethis;
	this->numOfMessages--;
}

bool User::verifyPass(string p){ 
	//verify that password entered matches saved password
	if(this->getPassword().compare(encrypt(p)) == false){
		return true;
	}
	else{
		return false;
	}
	/*
	if(mydb ->getPassword((char*)this->getUsername()).compare(encrypt(p)) == false){
		return true;
	}
	else{
		return false;
	}
	*/
}
/*
string User::encrypt(string uop){
	char key = 'P';
	string encrypted = uop;
	for(int i = 0; i < uop.size(); i++){
		encrypted[i] = uop[i] ^ key;
	}
	return encrypted;
}
*/
// Based on algorithm developed by Professor Daniel J. Bernstein
// Source for code: http://www.partow.net/programming/hashfunctions/
string User::DJBHash(string str)
{
   unsigned int hash = 5381;

   for (int i = 0; i < str.length(); ++i)
   {
      hash = ((hash << 5) + hash) + (str.at(i));
   }

   return to_string(hash);
}

// Using "stretching" algorithm as discussed in class 22
string User::encrypt(string uop){
	string salt = "puggopants";
	string encrypted = "0";
	
	// "Stretch" hash 3 times
	for(int i = 0; i < 3; i++){
		encrypted = DJBHash(encrypted + uop + salt);
	}
	
	return encrypted;
}

Message *User::getMessageList(){ //return message list of user
	return this->messageList;
}
string User::getUsername(){ //return username
	return this->username;
}

string User::getPassword(){ //return password
	return this->password;
}
int User::getNumOfMessages(){ //return the number of messages
	//char* uname = (char*)(this -> username);
	//const char* uname = username.c_str();
	//return mydb->noOfmsg(uname);
	return this->numOfMessages;
}
