#include<iostream>
#include<stdlib.h>
#include <string>
#include "Message.hpp"
#include "Message.cpp"
#include "Server.hpp"
#include "Server.cpp"
#include "User.hpp"
#include "User.cpp"
#include <sqlite3.h> 
#include "DBUTILITY.hpp"
using namespace std;


//No of line =<1> below edited by Arshiya #to get users from DB
//typedef vector<showUser> userlist;

int main(){
	
	/*// Front end start by Arshiya
	Frontend fe;
   string credentials= fe.login();
   cout << "Credentials are :"<< credentials ;
	//Front end completed by Arshiya*/
	
	//DB part start by Arshiya
	//DBUTILITY *mydb = new DBUTILITY();
	//Insert user
	/*char* name = (char*)"sam";
	string res = mydb->insertuser(name);
	cout << res << endl;*/
	//Show user
	
	
	//Insert messages
	/*char* usrname = (char*)"arshiya";
	char* header = (char*)"Regarding something";
	char* passphrase = (char*)"mysecretpasscode";
	char* content = (char*)"This is what I want to tell";
	char* sentfrom = (char*)"I am your contact";
	string msginsertstat = mydb-> insertmessage(usrname, header, passphrase, content, sentfrom);
	cout <<msginsertstat<<endl;
	
	//view messages
	char* username = (char*)"cold";
	msgdet beta = mydb ->selectmsg(username);
	for (int i =0 ; i<beta.size(); i++)
	{
	    cout << "name of "<< i+1<<"th msg : " << beta[i].username<< endl;
	    cout << "header of "<< i+1<<"th msg : " << beta[i].header<< endl;
	    cout << "content of "<< i+1<<"th msg : " << beta[i].content<< endl;
	    cout << "sender of "<< i+1<<"th msg : " << beta[i].sender<< endl;
	    cout << "time of "<< i+1<<"th msg : " << beta[i].timing<< endl;
	}
	
	//delete messages
//	char* username = (char*)"cold";
	char* when = (char*)"2017-11-10 18:39:45";
	string delres = mydb->delmsg(username, when);
	cout << delres << endl;	
	
	//DB part end by Arshiya
	
	*/
	Server* newServer = new Server(); //make the server
	while(true){ //continuous loop so people cant hack
		while(newServer->loggedin == false){ //while not logged in
			newServer->currentUser = newServer->bootUp(); //get user to log in
		} //end while
		newServer->welcomeMessage(); //welcome user
		while(newServer->loggedin == true){ //while user is logged in
			newServer->routine();
		}
	}
	//delete newServer;// TO CLOSE CONNECTION TO Server
	//delete mydb; // TO CLOSE CONNECTION TO DB
	return 0; //void
	
} // end main