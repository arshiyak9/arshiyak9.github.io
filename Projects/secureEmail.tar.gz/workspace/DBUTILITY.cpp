#include <iostream>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <vector>
#include <sqlite3.h> 
#include "DBUTILITY.hpp"
using namespace std;

//Constructor
DBUTILITY::DBUTILITY()
{
   rc = sqlite3_open("new.db", &db);
   
   if( rc ) {
      fprintf(stderr, "Can't open database: %s\n", sqlite3_errmsg(db));
      
   } else {
      fprintf(stderr, "Opened database successfully\n");
   } 
}

//Destructor
DBUTILITY::~DBUTILITY()
{
  sqlite3_close(db); 
  cout <<"Closed database successfully\n" <<endl;
}


// ####### USER DB FUNCTIONS | START | ###########
//get User list of server
showList DBUTILITY::showServerUsers()
{
    
    showList serverUsers;
    vector<string> temp;
    
    char *errmsg = NULL;
   
   rc = sqlite3_exec(db, "select * from USERS;", user_callback, &temp, &zErrMsg);
    if( rc != SQLITE_OK ){
        fprintf(stderr, "SQL error: %s\n", zErrMsg);
        sqlite3_free(zErrMsg);
    } else {
        fprintf(stdout, "Records display successfully\n");
    }
 
    for(int i = 0; i < temp.size(); i+=2) {
        serverUsers.push_back(new User(temp.at(i), temp.at(i+1)));
    }
    
    return serverUsers;
    
}


//get my user
string DBUTILITY::getMyUser(char* username) 
{
   
   string uname = NULL;;

sqlite3_stmt *stmt;
   //rc = sqlite3_exec(db, "select PASSWORD from USERS;", user_callback, &userls, &zErrMsg);
   
   if ( sqlite3_prepare(
         db, 
         "select NAME from USERS WHERE NAME = ?;",  // stmt //
        -1, // If than zero, then stmt is read up to the first nul terminator
        &stmt,
         0  // Pointer to unused portion of stmt
       )
       != SQLITE_OK) {
    printf("\nCould not prepare statement.");
    
  }
  
   if (sqlite3_bind_text (
        stmt,
        1,  // Index of wildcard
        username,
        strlen(username),  // length of text
        SQLITE_STATIC
        )
      != SQLITE_OK) {
    printf("\nCould not bind text.\n");
    
  }
  
  for (;;)
     {
        rc = sqlite3_step(stmt);
        if (rc == SQLITE_DONE)
            break;
        if (rc != SQLITE_ROW) {
            printf("error: %s!\n", sqlite3_errmsg(db));
            return "User not found";
        }
        
     string uname((const char *)sqlite3_column_text(stmt, 0));
     return uname;
    }
    
}

string DBUTILITY::getPassword(char* username) 
{
   
   string pwd= NULL;

sqlite3_stmt *stmt;
   //rc = sqlite3_exec(db, "select PASSWORD from USERS;", user_callback, &userls, &zErrMsg);
   
   if ( sqlite3_prepare(
         db, 
         "select PASSWORD from USERS WHERE NAME = ?;",  // stmt // IN MESSAGES TABLE ALTER TO DEFAULT CURRENT_TIMESTAMP
        -1, // If than zero, then stmt is read up to the first nul terminator
        &stmt,
         0  // Pointer to unused portion of stmt
       )
       != SQLITE_OK) {
    printf("\nCould not prepare statement.");
    
  }
  
   if (sqlite3_bind_text (
        stmt,
        1,  // Index of wildcard
        username,
        strlen(username),  // length of text
        SQLITE_STATIC
        )
      != SQLITE_OK) {
    printf("\nCould not bind text.\n");
    
  }
  
  for (;;)
     {
        rc = sqlite3_step(stmt);
        if (rc == SQLITE_DONE)
            break;
        if (rc != SQLITE_ROW) {
            printf("error: %s!\n", sqlite3_errmsg(db));
            return "Password not found";
        }
        
     string pwd((const char *)sqlite3_column_text(stmt, 0));
     return pwd;
    }
    
}

User* DBUTILITY::insertuser(char* name, char* pwd)
{
   sqlite3_stmt *stmt;
   cout << name << endl;
   cout << strlen(name) << endl;
   cout << pwd <<endl;
   cout << strlen(pwd) << endl;    

  // sql  = (char*)"INSERT INTO USERS (ID, NAME) VALUES (?,?);";
   if ( sqlite3_prepare(
         db, 
         "INSERT INTO USERS ( NAME, PASSWORD) VALUES (?,?);",  // stmt
        -1, // If than zero, then stmt is read up to the first nul terminator
        &stmt,
         0  // Pointer to unused portion of stmt
       )
       != SQLITE_OK) {
    printf("\nCould not prepare statement.");
  }
   

 if (sqlite3_bind_text (
        stmt,
        1,  // Index of wildcard
        name,
        strlen(name),  // length of text
        SQLITE_STATIC
        )
      != SQLITE_OK) {
    printf("\nCould not bind text.\n");
    
  }

 if (sqlite3_bind_text (
        stmt,
        2,  // Index of wildcard
        pwd,
        strlen(pwd),  // length of text
        SQLITE_STATIC
        )
      != SQLITE_OK) {
    printf("\nCould not bind text.\n");
    
  }

 if (sqlite3_step(stmt) != SQLITE_DONE) {
    printf("\nCould not step (execute) stmt.\n");
        return NULL;
  }
  
  else
  {
      User* temp = new User(name, pwd);
      return temp;
  }
   
}

// ####### USER DB FUNCTIONS | END | ###########

// ####### MESSAGES DB FUNCTIONS | START | ###########

//string insertmessage(char* username, char* header, char* passphrase, char* content, char* sentfrom)
string DBUTILITY::insertmessage(Message* msgToInsert)
{
   sqlite3_stmt *stmt;
   char* temp1 = const_cast<char*>(msgToInsert->getReceiver().c_str());
   char* temp2 = const_cast<char*>(msgToInsert->getHeader().c_str());
   char* temp3 = const_cast<char*>(msgToInsert->getPassphrase().c_str());
   char* temp4 = const_cast<char*>(msgToInsert->getContent().c_str());
   char* temp5 = const_cast<char*>(msgToInsert->getSender().c_str());
   if ( sqlite3_prepare(
         db, 
         "INSERT INTO MESSAGES (USERNAME, HEADER, PASSPHRASE,CONTENT, SENTFROM, TIME) VALUES (?,?,?,?,?,datetime());",  // stmt // IN MESSAGES TABLE ALTER TO DEFAULT CURRENT_TIMESTAMP
        -1, // If than zero, then stmt is read up to the first null terminator
        &stmt,
         0  // Pointer to unused portion of stmt
       )
       != SQLITE_OK) {
    printf("\nCould not prepare statement.");
  }

 if (sqlite3_bind_text (
        stmt,
        1,  // Index of wildcard
        temp1,
        strlen(temp1),  // length of text
        SQLITE_STATIC
        )
      != SQLITE_OK) {
    printf("\nCould not bind text.\n");
  }
  
  if (sqlite3_bind_text (
        stmt,
        2,  // Index of wildcard
        temp2,
        strlen(temp2),  // length of text
        SQLITE_STATIC
        )
      != SQLITE_OK) {
    printf("\nCould not bind text.\n");
  }
  
  if (sqlite3_bind_text (
        stmt,
        3,  // Index of wildcard
        temp3,
        strlen(temp3),  // length of text
        SQLITE_STATIC
        )
      != SQLITE_OK) {
    printf("\nCould not bind text.\n");
  }
  
  if (sqlite3_bind_text (
        stmt,
        4,  // Index of wildcard
        temp4,
        strlen(temp4),  // length of text
        SQLITE_STATIC
        )
      != SQLITE_OK) {
    printf("\nCould not bind text.\n");
  }
  
  if (sqlite3_bind_text (
        stmt,
        5,  // Index of wildcard
        temp5,
        strlen(temp5),  // length of text
        SQLITE_STATIC
        )
      != SQLITE_OK) {
    printf("\nCould not bind text.\n");
  }

if (sqlite3_step(stmt) != SQLITE_DONE) {
    printf("\nCould not step (execute) stmt.\n");
    return "Failure in adding msg.\n";
  }
  else return "successfully added msg\n";
}

msgList DBUTILITY::selectmsg(string u)
{
    
   char* username = const_cast<char*>(u.c_str());
   
   msgList msgls ;
   sqlite3_stmt *stmt;
 
   if ( sqlite3_prepare(
         db, 
         "select USERNAME, HEADER, PASSPHRASE, CONTENT, SENTFROM, TIME from MESSAGES WHERE USERNAME = ?;",  // stmt // IN MESSAGES TABLE ALTER TO DEFAULT CURRENT_TIMESTAMP
        -1, // If than zero, then stmt is read up to the first nul terminator
        &stmt,
         0  // Pointer to unused portion of stmt
       )
       != SQLITE_OK) {
    printf("\nCould not prepare statement.");
    
  }

 if (sqlite3_bind_text (
        stmt,
        1,  // Index of wildcard
        username,
        strlen(username),  // length of text
        SQLITE_STATIC
        )
      != SQLITE_OK) {
    printf("\nCould not bind text.\n");
    
  }
  
for (;;)
     {
        rc = sqlite3_step(stmt);
        if (rc == SQLITE_DONE)
            break;
        if (rc != SQLITE_ROW) {
            printf("error: %s!\n", sqlite3_errmsg(db));
            break;
            //return NULL;
        }
        
     //cout << "showMessage"<< endl;
     string name((const char *)sqlite3_column_text(stmt, 0));//convert const char* to string
     string header((const char *)sqlite3_column_text(stmt, 1));
     string passphrase((const char *)sqlite3_column_text(stmt, 2));
     string content((const char *)sqlite3_column_text(stmt, 3));
     string sendfrom((const char *)sqlite3_column_text(stmt, 4));
     string date((const char *)sqlite3_column_text(stmt, 5));
     
     Message* smsg= new Message(name,header,content, date, sendfrom, passphrase );
     /*smsg->username = name;
     smsg->header = header;
     smsg->passphrase = passphrase;
     smsg->content = content;
     smsg->sender = sendfrom;
     smsg->timing = date;*/
     msgls.push_back(smsg);
     }
     return msgls;
}

 
string DBUTILITY::delmsg(char* username, char* when)
{
   sqlite3_stmt *stmt;
   
   if ( sqlite3_prepare(
         db, 
         "DELETE FROM MESSAGES WHERE USERNAME = ? AND TIME = ?;",  // stmt
        -1, // If than zero, then stmt is read up to the first nul terminator
        &stmt,
         0  // Pointer to unused portion of stmt
       )
       != SQLITE_OK) {
    printf("\nCould not prepare statement.");
    
  }
  if (sqlite3_bind_text (
        stmt,
        1,  // Index of wildcard
        username,
        strlen(username),  // length of text
        SQLITE_STATIC
        )
      != SQLITE_OK) {
    printf("\nCould not bind text.\n");
    
  }
  
  if (sqlite3_bind_text (
        stmt,
        2,  // Index of wildcard
        when,
        strlen(when),  // length of text
        SQLITE_STATIC
        )
      != SQLITE_OK) {
    printf("\nCould not bind when .\n");
    
  }
  
  if (sqlite3_step(stmt) != SQLITE_DONE) {
    printf("\nCould not step (execute) stmt.\n");
    return "Could not delete";
   }
  else return "Deleted successfully";
}

int DBUTILITY::noOfmsg(char* name)
{
   sqlite3_stmt *stmt;
   int count=0;
  // sql  = (char*)"INSERT INTO USERS (ID, NAME) VALUES (?,?);";
   if ( sqlite3_prepare(
         db, 
         "select count(*) from MESSAGES where USERNAME = ?;",  // stmt
        -1, // If than zero, then stmt is read up to the first nul terminator
        &stmt,
         0  // Pointer to unused portion of stmt
       )
       != SQLITE_OK) {
    printf("\nCould not prepare statement.");
    
  }
   

 if (sqlite3_bind_text (
        stmt,
        1,  // Index of wildcard
        name,
        strlen(name),  // length of text
        SQLITE_STATIC
        )
      != SQLITE_OK) {
    printf("\nCould not bind text.\n");
    
  }

rc = sqlite3_step(stmt);
        if (rc == SQLITE_DONE)
           // break;
        if (rc != SQLITE_ROW) {
            printf("error: %s!\n", sqlite3_errmsg(db));
            return -1;
        }
        
     count = sqlite3_column_int(stmt, 0);
     return count;
   
}

string DBUTILITY::getPassphrase(string u) 
{
char* username = const_cast<char*>(u.c_str());
string phrase= NULL;
sqlite3_stmt *stmt;
   
   if ( sqlite3_prepare(
         db, 
         "select PASSPHRASE from MESSAGES WHERE USERNAME = ?;",  // stmt // IN MESSAGES TABLE ALTER TO DEFAULT CURRENT_TIMESTAMP
        -1, // If than zero, then stmt is read up to the first nul terminator
        &stmt,
         0  // Pointer to unused portion of stmt
       )
       != SQLITE_OK) {
    printf("\nCould not prepare statement.");
    
  }
  
   if (sqlite3_bind_text (
        stmt,
        1,  // Index of wildcard
        username,
        strlen(username),  // length of text
        SQLITE_STATIC
        )
      != SQLITE_OK) {
    printf("\nCould not bind text.\n");
    
  }
  
  for (;;)
     {
        rc = sqlite3_step(stmt);
        if (rc == SQLITE_DONE)
            break;
        if (rc != SQLITE_ROW) {
            printf("error: %s!\n", sqlite3_errmsg(db));
            return "Password not found";
        }
        
     string phrase((const char *)sqlite3_column_text(stmt, 0));
     return phrase;
    }
}

// ####### MESSAGE DB FUNCTIONS | END | ###########