#include "Server.hpp"
#include "User.hpp"
#include <iostream>
#include <stdlib.h>
#include <string>
#include <cctype>
#include <sstream>
#include <ctype.h>
#include <limits>
#include<vector>
#include <sqlite3.h> 
using namespace std;


Server::Server(){ //create server object
	name        = "GeeMail";
	loggedin    = false;
	mydb        = new DBUTILITY();
	ul          = mydb->showServerUsers();
	numOfUsers  = 0;
	currentUser = NULL;
}

//welcome msg
void Server::welcomeMessage(){ //recite welcome message based on the current user
	cout << "Welcome to " << this->name << ", " << currentUser->getUsername() << "! "<<endl;
}

//showUserList
User* Server::userExists(string name, string pwd){
	for(int i = 0; i < ul.size(); i++) {
		User* temp = ul.at(i);
    	if (temp->getUsername() == name && temp->getPassword() == encrypt(pwd)) //verify username and password given by user
    		return temp;
	}
    return NULL;
}

//logging in
User* Server::login(string u, string p){ //log existing user into server
	if(this->userExists(u,p) != NULL){
		msgdet myMessages = mydb->selectmsg(const_cast<char*>(u.c_str()));
		return this->userExists(u,p);
	}
	else
	{
		cout << "User Does Not Exist or Password is Incorrect; Try Again." << endl;
		string user;
		string pass;
		cout << "Enter Valid Username:" << endl;
		cin >> user;
		cout << "Enter Valid Password:" << endl;
		cin >> pass;
		return login(user, pass);
	}
}

//register user
User* Server::reg(string u, string p){
	User* newuser = mydb->insertuser(const_cast<char*>(u.c_str()), const_cast<char*>(p.c_str()));
	if (newuser!= NULL){
	return newuser;}
	else
	{
		cout <<"Please provide valid entries.";
		return reg(u,p);
	}
}

//boot the server
User* Server::bootUp(){ //get user to log in or register
	cout << "Log in (l) or register (r)?" << endl;
	string l;
	getline( cin, l );
	User* sender = NULL;
	if(l.compare("l") == false /*&& this->numOfUsers != 0*/){ //if user chooses to log in and there are existing members
		string user;
		string pass;
		cout << "Enter Username:" << endl;
		getline( cin, user );
		while( user.length() < 1 ){
			cout << "Username must contain at least 1 character." << endl;
			cout << "Enter Username:" << endl;
		    getline( cin, user );
		}
		cout << "Enter Password:" << endl;
		getline( cin, pass );
		while( pass.length() < 1 ){
			cout << "Password must contain at least 1 character." << endl;
			cout << "Enter Password:" << endl;
		    getline( cin, pass );
		}

		sender=login(user, pass);
		loggedin=true;
		return sender;
	}
	else if(l.compare("r") == false){ //if user chooses to register
		string us;
		string pa;
		cout << "Create Username:" << endl;
		getline( cin, us );
		while(us.length() < 1 ){
			cout << "Username must contain at least 1 character." << endl;
			cout << "Enter Username:" << endl;
		    getline( cin, us );
		}
		cout << "Create Password:" << endl;
		getline( cin, pa );
		while( pa.length() < 1 ){
			cout << "Password must contain at least 1 character." << endl;
			cout << "Enter Password:" << endl;
		    getline( cin, pa );
		}
		sender=reg(us, pa);
		loggedin = true;
		return sender;
	}
	else{ //if user typed in any other input
		cout << "Login Failed" << endl;
		loggedin = false;
		return bootUp();
	}
}


//routine
void Server::routine(){ //preform standard routine once user is logged in
	
	cout << endl << "You have: " << currentUser->getNumOfMessages(mydb) << " messages." << endl; 
	currentUser->printAllMessages(mydb); //brief synopsis of all of current user's messages
	cout<< endl << "What would you like to do?" << endl;
	string stuff, value;
	std::stringstream ss;
	cout << "You can:"<<endl;
	cout << "Delete a message = d" << endl;
	cout << "Read a message   = r" << endl;
	cout << "Send a message   = s" << endl;
	cout << "Log out          = l" << endl;
	cout << "Exit program     = x" << endl;

	getline( cin, stuff );
	
    // d  DELETE A MESSAGE
	if(stuff.compare("d") == 0 && currentUser->getNumOfMessages(mydb) > 0){ //if string typed in is d (delete a letter)
	    currentUser->printAllMessages( mydb );
	    int numMsgs = currentUser->getNumOfMessages(mydb);
		cout << "Type the number of the message you'd like to delete:" << endl;
		int num = 10000000;
		getline( cin, value ); //user chooses message to read
        ss.clear(); ss.str(value);
        ss >> num;
		while( num<=0 || num>numMsgs ){ //only go forward if what they type is valid
			cout << "Valid Number Please:" << endl;
   		    getline( cin, value ); //user chooses message to read
            ss.clear(); ss.str(value);
            ss >> num;
		}
		string tempDel = currentUser->deleteMessage(mydb, num); //delete the message the user wants to delete
	    cout <<tempDel<< endl;
	}//Message delete end
	
	// r  READ A MESSAGE
	else if(stuff.compare("r") == 0 && currentUser->getNumOfMessages(mydb) > 0){ //if string typed is r (read a message)
		cout << "Please choose the corresponding number on the message:" << endl;
		int i = 100000;
		getline( cin, value ); //user chooses message to read
        ss.clear(); ss.str(value);
        ss >> i;
    
        while(i>currentUser->getNumOfMessages(mydb) || i<=0 ){ //while the user doesnt type a valid number
			cout << "Valid Number Please:" << endl;
		    getline( cin, value ); //user chooses message to read
		    ss.clear(); ss.str(value);
            ss >> i;
		}

		cout << "Please enter the passphrase:" << endl;
		getline( cin, value ); //user input for passphrase
		bool giveUp = false;

        while( currentUser->checkPassphrase( mydb, value, i ) == false ) {
        	string str;
			cout << "Incorrect passcode.  Enter correct passcode or 'q' to return to main menu:" << endl;
		    getline( cin, str ); //user input for passphrase
		    if( str.compare( "q" ) == 0 ){
		    	giveUp = true;
		    	break;
		    }
		}
		if( !giveUp )
    		currentUser->printWholeMessage(mydb, i, value); //print the message the user wants to read
	}// end read message
	
	// s  SEND A MESSAGE
	else if(stuff.compare("s")== false){ //if string typed in is s
		string sendTo;
		cout << "To: ";
			getline( cin, sendTo ); //get sender to choose recipient
		bool found = false;
		for(int j=0; j<ul.size(); j++)
		{
			if(sendTo.compare(ul[j]->getUsername())==0)
			{
			    found = true;
			    break;
			}
		}
		while(!found) {
			cout << endl << "User not Found. Enter valid user: ";
			getline( cin, sendTo );
			for(int j=0; j<ul.size(); j++)
			{
				if(sendTo.compare(ul[j]->getUsername())==false)
				{
					found = true;
					continue;
				}
			}
		}
		string header;
		cout << "Header: "; 
			getline(cin, header); //get sender to type header for message
		string message;
		cout << "Message: ";
		getline(cin, message); //get sender to type content for message
		cout << "Passphrase: ";
		string phrase;
		getline(cin, phrase); //get sender to type shared passphrase for message

        string insertRes=currentUser->sendMessage( mydb, header, message, sendTo, phrase); //send the message to the intended recipient]
		cout << endl << insertRes << endl;
	}//end send msg
	
	// l  LOG IN/LOG OUT
	else if(stuff.compare("l")== false){ //if string typed in is l
		cout << "Until next time, " << currentUser->getUsername() << endl; //goodbye message
		loggedin = false; //logged in status of server is changed to false
	}
	
	// x  EXIT PROGRAM
	else if(stuff.compare("x") == 0){
	    cout << "Exiting..." << endl;
	    exit( 0 );
	}
	
	// other
	else{
		cout << "Input not valid, try again" << endl;
		routine(); //this function calls itself again
	}
}

string Server::DJBHash(string str)
{
   unsigned int hash = 5381;

   for (int i = 0; i < str.length(); ++i)
      hash = ((hash << 5) + hash) + (str.at(i));

   return to_string(hash);
}

// Using "stretching" algorithm as discussed in class 22
string Server::encrypt(string uop){
	string salt = "puggopants";
	string encrypted = "0";
	
	// "Stretch" hash 3 times
	for(int i = 0; i < 3; i++){
		encrypted = DJBHash(encrypted + uop + salt);
	}
	
	return encrypted;
}
