#include <string>
#include <iostream>
#include <stdlib.h>
#include "Server.cpp"
#include "User.cpp"
#include "Message.cpp"
#include "DBUTILITY.cpp"

using namespace std;

	int main(){
		
		Server* newServer = new Server(); //make the server
		while(true){ //continuous loop so people cant hack
		while(newServer->loggedin == false){ //while not logged in
			newServer->currentUser = newServer->bootUp(); //get user to log in
		} //end while
		newServer->welcomeMessage(); //welcome user
		while(newServer->loggedin == true){ //while user is logged in
			newServer->routine();
		}
	}
	delete newServer;// TO CLOSE CONNECTION TO Server
	return 0; //void
}// end main
