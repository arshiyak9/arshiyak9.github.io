#ifndef MESSAGE_HPP_
#define MESSAGE_HPP_
#include <iostream>
#include <stdlib.h>
#include <string>
using namespace std;
 

class Message{
	public:
		string receiver;
		string header;
		string content;
		string messageEncryptionWithPassphrase( string uop, string key );
		string passphrase;
		string timing;
		string sender;
		Message(string r, string h, string c, string t, string s, string p);
		Message(string r, string h, string c, string s, string p);
		string getReceiver();
		string getHeader();
		string getContent();
		string getPassphrase();
		string getSender();
        string encrypt(string uop);
		string DJBHash(string str);
};

#endif /* MESSAGE_HPP_ */