#ifndef SERVER_HPP_
#define SERVER_HPP_
#include <iostream>
#include <stdlib.h>
#include <string>
#include "Message.hpp"
#include "User.hpp"
#include <vector>
using namespace std;

//typedef std::vector<string> UserList;//List of Users in server (make sure none can make the same username)

class Server{
public:
	string name; //name of server
	void welcomeMessage(); //standard welcome message for server
	 
	User* currentUser;
	//UserList usernamelist;
	vector<User> userlist;
	int numOfUsers; //the number of users
	Server(); //constructor
	~Server(); //destructor
	User* bootUp(); //get user to log in/register
	User* login(string u, string p); //log in to existing user
	User* reg(string u, string p); //register new user
	User* getUser(int num); //pull a certain user
	void routine(); //list of commands users can access when logged in
	bool loggedin; //true if user is logged in, false if not
	int userExists(string user); //finds if a certain user exists in the list
	string encrypt(string uop);
	string DJBHash(string str);
};

#endif /* SERVER_HPP_ */
