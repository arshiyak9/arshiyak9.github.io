#include "Message.hpp"
#include <iostream>
#include <stdlib.h>
#include <string>

using namespace std;

// THIS CONSTRUCTOR CALLED WHEN MESSAGE EXTRACTED FROM DB
Message::Message(string r, string h, string c, string t, string s, string p){ //constructor for message
	receiver = r;
	header = h;
    sender = s;
    passphrase = p;  // ENCRYPTED
	timing = t;
    content = c;     // ENCRYPTED
}

// THIS CONSTRUCTOR CALLED WHEN USER SENDS A NEW MESSAGE
Message::Message(string r, string h, string c, string s, string p){ //constructor for message
	sender = s;
	header = h;
	receiver = r;
	passphrase = encrypt(p);
	content = messageEncryptionWithPassphrase( c, encrypt(passphrase) );
}


string Message::getReceiver(){ //get username of receiver
	return this->receiver;
}

string Message::getHeader(){ //get header of message
	return this->header;
}

string Message::getContent(){ //get content of message
//	return messageEncryptionWithPassphrase(this->content);
return this->content;
}


string Message::getPassphrase(){ //get passphrase for message
	return this->passphrase;
}

string Message::getSender(){ //get sender for message
	return this->sender;
}
// Based on algorithm developed by Professor Daniel J. Bernstein
// Source for code: http://www.partow.net/programming/hashfunctions/
string Message::DJBHash(string str)
{
   unsigned int hash = 5381;

   for (int i = 0; i < str.length(); ++i)
   {
      hash = ((hash << 5) + hash) + (str.at(i));
   }
   return to_string(hash);
}

// Using "stretching" algorithm as discussed in class 22
string Message::encrypt(string uop){
	string salt = "puggopants";
	string encrypted = "0";
	
	// "Stretch" hash 3 times
	for(int i = 0; i < 3; i++){
		encrypted = DJBHash(encrypted + uop + salt);
	}
	
	return encrypted;
}

string Message::messageEncryptionWithPassphrase(string uop, string key){
//	string key= this->passphrase;
	string encrypted = uop;
	for(int i = 0; i < uop.size(); i++){
		for(int j = 0; j < key.size(); j++){
			encrypted[i] = uop[i] ^ key[j];
		}
	}
	return encrypted;
}