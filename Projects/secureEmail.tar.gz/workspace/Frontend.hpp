#ifndef Frontend_HPP_
#define Frontend_HPP_
#include <iostream>
#include <stdlib.h>
#include <string>
using namespace std;

class Frontend
{

public :
string login()
{
   cout << "Content-type:text/html\r\n\r\n";
   cout << "<html>\n";
   cout << "<meta charset=\"UTF-8\">";
   cout << "<head>\n";
   cout << "<title>CGI Envrionment Variables</title>\n";
   cout << "</head>\n";
   cout << "<body>\n";
   cout << "<div align = \"center\"><form name = \"GEEmail\"  method = \"GET\">" << endl;
   cout << "<h2>Welcome!!! Please provide your username and Password.</h2>" << endl;
   
   cout << "<br><label for=\"usernameis\">Username: </label>";
   cout << "<input type=\"text\" name=\"username \"><br />" << endl;
   
   cout << "<label for=\"passwordis\">password: </label>";
   cout << "<input type=\"password\" name=\"password\"><br>" << endl;
   
   cout << "<input type=\"submit\" value=\"send\"> <input type=\"reset\">";
   
   cout << "</form></div><div align = \"center\">" << endl;
   cout <<  "<button name= \"newuser\" >" <<endl;
  
   cout << "</div>";
   cout << "</body>";
   cout << "</html>";
   
   char *value = getenv( "QUERY_STRING" ); 
	cout << value;
   return value;
}

};

#endif
