#include "User.hpp"
#include <stdlib.h>
#include <string>
#include <cstring>
#include <iostream>
using namespace std;

//PART-1
User::User(string u, string p){ //constructor for User
	username = u; //set the username
	password = encrypt(p); //set the password
	numOfMessages = 0; //number of messages new user has is 0 in beginning
} //end constructor

// getters
string User::getUsername(){ //return username
	return this->username;
}

string User::getPassword(){ //return password
	return this->password;
}

int User::getNumOfMessages(DBUTILITY* mydb){ //return the number of messages

	const char *uname = (this->getUsername()).c_str();
	return mydb->noOfmsg(const_cast<char*>(uname));
	
}

//PART-2 encryption
string User::DJBHash(string str)
{
   unsigned int hash = 5381;

   for (int i = 0; i < str.length(); ++i)
   {
      hash = ((hash << 5) + hash) + (str.at(i));
   }
   return to_string(hash);
}

//Using "stretching" algorithm as discussed in class 22
string User::encrypt(string uop){
	string salt = "puggopants";
	string encrypted = "0";
	// "Stretch" hash 3 times
	for(int i = 0; i < 3; i++){
		encrypted = DJBHash(encrypted + uop + salt);
	}
	return encrypted;
}


//PART-3 synopsis of msg
void User::printAllMessages(DBUTILITY* mydb){ //print a brief synopsis of every message in the user's message list
    msgdet myMessages = mydb->selectmsg(username.c_str());
	if(myMessages.size() != 0){
		cout << "You have the following messages:" << endl;
		for(int i=0; i<myMessages.size(); i++){
			//toPrint = this->getMessage(i);
			cout <<endl<< "# " << (i+1);
			cout << " ~From: " << myMessages[i]->sender;
			cout << " ~To: " << myMessages[i]->receiver;
			cout << " ~Subject: " << myMessages[i]->header;
			cout << endl;
		}
	}
}

//delete message
string User::deleteMessage(DBUTILITY* mydb, int num){ //use to delete message from user's message list
	msgdet myMessages = mydb -> selectmsg(username.c_str());
	if(myMessages.size() != 0 && num-1<=myMessages.size())
	{
		string deletemyname = myMessages[num-1]->receiver;
		string deletemytime = myMessages[num-1]->timing;
		string msgDelRes = mydb->delmsg(const_cast<char*>(deletemyname.c_str()), const_cast<char*>(deletemytime.c_str()));
		return msgDelRes;
	}
}

//get passphrase from message num
string User::getPassphrase(DBUTILITY* mydb, int num){
	msgdet myMessages = mydb -> selectmsg(username.c_str());
	if( myMessages.size() != 0 && num-1<=myMessages.size() )
	{
		return myMessages[num-1]->getPassphrase();
	}
}


//get passphrase from message num and compare to phrase
bool User::checkPassphrase(DBUTILITY* mydb, string phrase, int num){
	msgdet myMessages = mydb -> selectmsg(username.c_str());
	if( myMessages.size() != 0 && num-1<=myMessages.size() )
	{
		string encrypted =  myMessages[num-1]->encrypt( phrase );
		if( encrypted.compare( myMessages[num-1]->getPassphrase() ) == 0 )
		    return true;
		return false;
	}
	return false;
}


//print whole msg
void User::printWholeMessage(DBUTILITY* mydb, int i, string phrase){ // print an entire message in the user's message list
	msgdet myMessages = mydb -> selectmsg(username.c_str());
	if(myMessages.size() != 0 && i-1<=myMessages.size())
	{
		cout << endl << "Your message is"<< endl;
		cout << endl << " ~From:     " << myMessages[i-1]->sender <<endl;
		cout << endl << " ~To:       " << myMessages[i-1]->receiver <<endl;
		cout << " ~Subject:  " << myMessages[i-1]->header << endl;
        string v = myMessages[i-1]->encrypt( phrase ); 
        v = myMessages[i-1]->encrypt( v ); 
		v = myMessages[i-1]-> messageEncryptionWithPassphrase(myMessages[i-1]->content, v);
		cout << " ~Message:  " << v << endl;
		cout << " ~Sent at:  " << myMessages[i-1]->timing << endl;
	}
}


//send message
string User::sendMessage(DBUTILITY* mydb, string header, string content, string sendTo, string pass){
	Message* tosend = new Message(sendTo, header, content, this->getUsername(), pass);
	string msginsertstat=mydb ->insertmessage(tosend);
	//cout <<msginsertstat<<endl;
	return msginsertstat;
} 
