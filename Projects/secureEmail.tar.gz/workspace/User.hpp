#ifndef USER_HPP_
#define USER_HPP_

class Message;

#include <string>
#include<iostream>
#include<stdlib.h>
#include <vector>
#include "DBUTILITY.hpp"

using namespace std;

class User{
	private:
		string username;
		string password;
		int numOfMessages;
		
	public:
//		User * next;
//PART-1

		string encrypt(string uop);
		string DJBHash(string i);
		User(string u, string p);//constructor
		~User();
		string getUsername();
		string getPassword();
		void setUsername(string u) {
			this->username = u;
		}
		void setPassword(string p) {
			this->password = p;
		}
		int getNumOfMessages(DBUTILITY* mydb);
//PART-2
		
		
//PART-3	
        string getPassphrase(DBUTILITY*, int);
        void printAllMessages(DBUTILITY* mydb);
		string deleteMessage(DBUTILITY* mydb, int num);
		void printWholeMessage(DBUTILITY* mydb, int i, string p);
		string sendMessage(DBUTILITY* mydb, string header, string content, string sendTo, string pass);
        bool checkPassphrase(DBUTILITY* mydb, string phrase, int num);
};

#endif /* USER_HPP_ */