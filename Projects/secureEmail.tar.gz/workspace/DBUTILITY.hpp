#ifndef DBUTILITY_HPP_
#define DBUTILITY_HPP_

class User;
class Message;

#include <iostream>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <vector>
#include <sqlite3.h> 
using namespace std;

struct showUser
{
    string showName;
    string showPass;
    int numOfMessages =0;
};

struct showMessage
{
   string username;
   string header;
   string passphrase;
   string content;
   string sender;
   string timing;
};

typedef std::vector<User*> showList ;
typedef std::vector<Message*> msgList ;

class DBUTILITY
{
private:

   sqlite3* db;
   char *zErrMsg;
   int rc;
   char *sql;
   
   
   static inline int user_callback(void *ptr, int argc, char **argv, char **azColName) {
      
      vector<string> *users = reinterpret_cast<vector<string>*>(ptr);
      
      users->push_back(argv[1]);
      users->push_back(argv[2]);
      
      return 0;
   }


public :

//Constructor
DBUTILITY();

//Destructor
~DBUTILITY();


// ####### USER DB FUNCTIONS | START | ###########
//get User list of server

showList showServerUsers();


//get my user
string getMyUser(char* username);

string getPassword(char* username);

User* insertuser(char* name, char* pwd);

// ####### USER DB FUNCTIONS | END | ###########

// ####### MESSAGES DB FUNCTIONS | START | ###########

string insertmessage(Message* msgToInsert);

msgList selectmsg(string u);
 
string delmsg(char* username, char* when);

int noOfmsg(char* name);

string getPassphrase(string u) ;

// ####### MESSAGE DB FUNCTIONS | END | ###########
};

#endif